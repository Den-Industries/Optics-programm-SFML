#include <SFML/Graphics.hpp>
#include <iostream>
#include <sstream>
#include <Windows.h>
#include <time.h>
#include <string>
#include "view.h"
#include <math.h>

using namespace sf;
using namespace std;

float evenly(float shit, int shit1)
{
	shit *= shit1;
	shit = nearbyint(shit);
	shit /= shit1;
	return shit;
}

int main()
{
	setlocale(LC_ALL, "ru");
	srand(time(NULL));
	int sw = GetSystemMetrics(SM_CXSCREEN);
	int sh = GetSystemMetrics(SM_CYSCREEN);
	float stuffy = -126;
	float culldown = 5;
	int lighterrot = 45;
	int lensrot = 0;
	int refraction = 10;
	int lightercords[2] = {100, int(sh / 2)};
	int lenscords[2] = { int(sw / 2), int(sh / 2) };
	int folowing = 0;
	int mousechange[2];

	Image exit_image;
	exit_image.loadFromFile("images/exitimage.png");
	exit_image.createMaskFromColor(Color(255, 255, 255));
	Texture exit_t;
	exit_t.loadFromImage(exit_image);
	Sprite s_exit;
	s_exit.setTexture(exit_t);

	Image lighter_image;
	lighter_image.loadFromFile("images/stuff.png");
	lighter_image.createMaskFromColor(Color(255, 255, 255));
	Texture lighter_t;
	lighter_t.loadFromImage(lighter_image);
	Sprite s_lighter;
	s_lighter.setTexture(lighter_t);
	s_lighter.setTextureRect(IntRect(0, 64, 128, 56));
	s_lighter.setPosition(lightercords[0], lightercords[1]);
	s_lighter.setRotation(lighterrot);
	

	Image bg_image;
	bg_image.loadFromFile("images/bg.png");
	bg_image.createMaskFromColor(Color(255, 255, 255));
	Texture bg_t;
	bg_t.loadFromImage(bg_image);
	Sprite s_bg;
	s_bg.setTexture(bg_t);

	Image point_image;
	point_image.loadFromFile("images/stuff.png");
	point_image.createMaskFromColor(Color(255, 255, 255));
	Texture point_t;
	point_t.loadFromImage(point_image);
	Sprite point_s[2];
	point_s[0].setTexture(point_t);
	point_s[1].setTexture(point_t);
	point_s[0].setTextureRect(IntRect(128, 0, 2, 2));
	point_s[1].setTextureRect(IntRect(134, 0, 2, 2));
	point_s[0].setPosition(0, 0);
	point_s[1].setPosition(0, 0);
	point_s[0].setColor(Color(255, 255, 255, 100));
	point_s[1].setColor(Color(255, 255, 255, 100));

	Image stuff_image;
	stuff_image.loadFromFile("images/stuff.png");
	stuff_image.createMaskFromColor(Color(255, 255, 255));
	Texture stuff_t;
	stuff_t.loadFromImage(stuff_image);
	const int qofstuff = 4;
	Sprite s_stuff[4];
	for (int i = 0; i < qofstuff; i++)
	{
		s_stuff[i].setTexture(stuff_t);
		if (i % 2 == 0) s_stuff[i].setTextureRect(IntRect(0, 0, 64, 64));
		else s_stuff[i].setTextureRect(IntRect(64, 0, 64, 64));
	}

	//���������� ������
	if (true)
	{
		s_stuff[0].setPosition(sw - 128, sh - 64);
		s_stuff[1].setPosition(sw - 64, sh - 64);
		s_stuff[2].setPosition(sw - 256, sh - 64);
		s_stuff[3].setPosition(sw - 192, sh - 64);
	}

	RenderWindow window(sf::VideoMode(sw, sh), "Optics", Style::Fullscreen);
	view.reset(sf::FloatRect(0, 0, sw, sh));
	window.setPosition(Vector2i(0, 0));
	Clock clock;
	getplayercoordinateforview(int(sw / 2), int(sh / 2));

	float mouseshit[2] = {0, 0};
	float optimiz = 4;

	while (window.isOpen())
	{
		float time = clock.getElapsedTime().asMilliseconds();
		clock.restart();
		if (culldown < 5) culldown += time * 0.05;
		if (culldown >= 5)
		{
			for (int i = 0; i < qofstuff; i++)
				s_stuff[i].setColor(Color(255, 255, 255));
		}

		if (Keyboard::isKeyPressed(Keyboard::Escape))
		{
			s_exit.setColor(Color(200, 200, 200));
			window.draw(s_exit);
			window.display();
			Sleep(300);
			window.close();
		}

		Vector2i pixelPos = Mouse::getPosition(window);
		Vector2f pos = window.mapPixelToCoords(pixelPos);
		Event event;

		while (window.pollEvent(event))
		{
			if (event.type == sf::Event::Closed)
				window.close();
			if (event.type == Event::MouseButtonPressed)//���� ������ ������� ����
				if (event.key.code == Mouse::Left) {//� ������ �����
					if (s_exit.getGlobalBounds().contains(pos.x, pos.y))//� ��� ���� ���������� ������� �������� � ������
					{
						s_exit.setColor(Color::Green);
						window.draw(s_exit);
						window.display();
						Sleep(300);
						window.close();
					}
					if (s_lighter.getGlobalBounds().contains(pos.x, pos.y))//� ��� ���� ���������� ������� �������� � ������
					{
						folowing = 1;
						s_lighter.setColor(Color(220, 220, 220));
					}
					if (pos.x > lenscords[0] - 50 && pos.x < lenscords[0] + 50 && pos.y > lenscords[1] - 50 && pos.y < lenscords[1] + 50)//� ��� ���� ���������� ������� �������� � ������
					{
						folowing = 2;
						point_s[0].setColor(Color(220, 220, 220));
					}
					if (true)
					{
						int pressedbut = -1;
						for (int i = 0; i < qofstuff; i++)
							if (s_stuff[i].getGlobalBounds().contains(pos.x, pos.y))
								pressedbut = i;

						if (pressedbut == 0) refraction -= 25;
						if (pressedbut == 1) refraction += 25;
						if (pressedbut == 2) optimiz = optimiz * 2;
						if (pressedbut == 3) optimiz = optimiz / 2;

						if (pressedbut != -1)
						{
							culldown = 0;
							s_stuff[pressedbut].setColor(Color(200, 200, 200));
						}
					}
				}
			if (event.type == Event::MouseButtonReleased)
				if (event.key.code == Mouse::Left)
					folowing = 0;
			if (event.type == Event::MouseWheelMoved)
			{
				if (folowing == 1)
				{
					lighterrot += event.key.code * 5;
					s_lighter.setRotation(lighterrot);
				}
				if (folowing == 2)
				{
					lensrot += event.key.code * 5;
				}
			}
		}

		if (folowing != 0)
		{
			if (folowing == 1)
			{
				lightercords[0] += pos.x - mouseshit[0];
				lightercords[1] += pos.y - mouseshit[1];
				s_lighter.setPosition(lightercords[0], lightercords[1]);
			}
			else
			{
				lenscords[0] += pos.x - mouseshit[0];
				lenscords[1] += pos.y - mouseshit[1];
			}
		}
		else
		{
			s_lighter.setColor(Color(255, 255, 255));
			point_s[0].setColor(Color(255, 255, 255));
		}

		mouseshit[0] = pos.x;
		mouseshit[1] = pos.y;

		if (pos.y > 128)
		{
			if (stuffy > -126) stuffy -= 0.5 * time;
		}
		else
			if (stuffy < 0) stuffy += 0.5 * time;
		if (stuffy > 0) stuffy = 0;
		if (stuffy < -126) stuffy = -126;

		window.setView(view);
		window.clear();
		window.getSystemHandle();

		window.draw(s_bg);

		if (true)
		{
			//128 / 56
			for (int i = 2; i < 54 / optimiz; i++)
			{
				point_s[1].setColor(Color(255, 255, 255, 100));
				float cosin = cos(lighterrot * 0.0175);
				float sinus = sin(lighterrot * 0.0175);
				float lightcords[2] = { int(lightercords[0] + int(((128 * cosin) - ((i * optimiz) * sinus)))), int(lightercords[1] + int((128 * sinus) + ((i * optimiz) * cosin))) };
				point_s[1].setPosition(lightcords[0], lightcords[1]);
				float move[2];
				move[0] = cos(lighterrot * 0.0175);
				move[1] = sin(lighterrot * 0.0175);
				while (lightcords[0] > 0 && lightcords[0] < sw && lightcords[1] > 0 && lightcords[1] < sh)
				{
					bool lensishere = false;
					cosin = cos(lensrot * 0.0175);
					sinus = sin(lensrot * 0.0175);
					for (int u = -100; u < 100; u++)
						for (int z = -3; z < 3; z++)
						{
							float shit[2];
							shit[0] = lenscords[0] + (z * cosin - u * sinus);
							shit[1] = lenscords[1] + (z * sinus + u * cosin);
							if (int(lightcords[0] / 2) == int(shit[0] / 2) && int(lightcords[1] / 2) == int(shit[1] / 2))
								lensishere = true;
						}
					if (lensishere)
					{
						/*
						if (lensrot == lighterrot)
						{
							float mnimfocus[2];
							float fosucshit[2];
							fosucshit[0] = lenscords[0] + (refraction * cosin);
							fosucshit[1] = lenscords[1] + (refraction * sinus);
							float dist = sqrt(pow(fosucshit[0] - lightcords[0], 2) + pow(fosucshit[1] - lightcords[1], 2));
							move[0] = ((fosucshit[0] - lightcords[0]) / dist);
							move[1] = ((fosucshit[1] - lightcords[1]) / dist);
							if (refraction < 0)
							{
								move[0] = -move[0];
								move[1] = -move[1];
							}
						}
						else
						{*/
							int shiit = 7;
							bool findit = false;
							float fosucshit[2];
							int kuda = 2;
							fosucshit[0] = lightcords[0];
							fosucshit[1] = lightcords[1];
							lightcords[0] = lenscords[0];
							lightcords[1] = lenscords[1];
							cosin = cos(lensrot * 0.0175);
							sinus = sin(lensrot * 0.0175);
							if (true)
							{
								/*
								float shit[2];
								shit[0] = lenscords[0] + refraction * cosin;
								shit[1] = lenscords[1] + refraction * sinus;
								float dist = sqrt(pow(lightcords[0] - shit[0], 2) + pow(lightcords[1] - shit[1], 2));
								lightcords[0] += move[0] * 3;
								lightcords[1] += move[1] * 3;
								if (dist > sqrt(pow(lightcords[0] - shit[0], 2) + pow(lightcords[1] - shit[1], 2)))
									kuda = 1;
									*/
								if (refraction < 0) kuda = 2;
								else kuda = 1;
							}
							float stuff1 = refraction * cosin;
							float stuff2 = refraction * sinus;
							for (int g = 0; g < 300; g++)
							{
								if (!findit && kuda == 1)
								{
									lightcords[0] += move[0] * 3;
									lightcords[1] += move[1] * 3;
								}
								if (!findit && kuda == 2)
								{
									lightcords[0] -= move[0] * 3;
									lightcords[1] -= move[1] * 3;
								}
								for (int u = -400; u < 400; u += 3)
									for (int z = -1; z < 1; z++)
									{
										float shit[2];
										shit[0] = lenscords[0] + stuff1 + (z * cosin - u * sinus);
										shit[1] = lenscords[1] + stuff2 + (z * sinus + u * cosin);
										if (int(lightcords[0] / shiit) == int(shit[0] / shiit) && int(lightcords[1] / shiit) == int(shit[1] / shiit))
										{
											findit = true;
										}
										shit[0] = lenscords[0] - stuff1 + (z * cosin - u * sinus);
										shit[1] = lenscords[1] - stuff2 + (z * sinus + u * cosin);
										if (int(lightcords[0] / shiit) == int(shit[0] / shiit) && int(lightcords[1] / shiit) == int(shit[1] / shiit))
										{
											findit = true;
										}
									}
								if (findit) g = 301;
							}

							float dist = sqrt(pow(lightcords[0] - fosucshit[0], 2) + pow(lightcords[1] - fosucshit[1], 2));
							move[0] = ((lightcords[0] - fosucshit[0]) / dist);
							move[1] = ((lightcords[1] - fosucshit[1]) / dist);
							if (refraction < 0)
							{
								move[0] = -move[0];
								move[1] = -move[1];
							}
							lightcords[0] = fosucshit[0];
							lightcords[1] = fosucshit[1];
							for (int g = 0; g < 50; g++)
							{
								lightcords[0] += move[0];
								lightcords[1] += move[1];
								point_s[1].setPosition(int(lightcords[0]), int(lightcords[1]));
								window.draw(point_s[1]);
							}
						//}
					}
					lightcords[0] += move[0];
					lightcords[1] += move[1];
					point_s[1].setPosition(int(lightcords[0]), int(lightcords[1]));
					window.draw(point_s[1]);
				}
			}
		}

		window.draw(s_lighter);

		if (true)
		{
			float fuck = 0.05;
			float refr = (refraction / 9) + 1;
			float cosin = cos(lensrot * 0.0175);
			float sinus = sin(lensrot * 0.0175);
			if (refraction > 0)
				for (int i = -100; i < 100; i++)
				{
					int shit = int(sqrt(abs(pow(refr, 2)) - (i * i * abs(pow(refr, 2))) / 10000));
					if (shit >= refr) shit = refr - 1;
					for (int u = -(shit * (1 - fuck)) - refr * fuck; u < (shit * (1 - fuck)) + refr * fuck; u++)
					{
						point_s[0].setPosition(lenscords[0] + (u * cosin - i * sinus), lenscords[1] + (u * sinus + i * cosin));
						window.draw(point_s[0]);
					}
				}
			else
			{
				for (int i = -100; i < 100; i++)
				{
					refr = abs(refr);
					int shit = int(sqrt(abs(pow(refr, 2)) - (i * i * abs(pow(refr, 2))) / 10000));
					shit -= refr;
					shit = abs(shit);
					if (shit >= refr - 2) shit = refr - 2;
					if (shit <= 1) shit = 1;
					for (int u = -(shit * (1 - fuck)) - refr * fuck; u < (shit * (1 - fuck)) + refr * fuck; u++)
					{
						point_s[0].setPosition(lenscords[0] + (u * cosin - i * sinus), lenscords[1] + (u * sinus + i * cosin));
						window.draw(point_s[0]);
					}
				}
			}
		}
		
		for (int i = 0; i < qofstuff; i++) window.draw(s_stuff[i]);

		s_exit.setPosition(getviewx() + int(sw / 2) - 126, getviewy() - int(sh / 2) + stuffy);
		window.draw(s_exit);
		window.display();
		// 1 � 9
	}
	return 0;
}